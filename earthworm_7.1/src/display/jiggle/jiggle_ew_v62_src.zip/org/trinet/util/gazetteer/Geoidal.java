package org.trinet.util.gazetteer;
public interface Geoidal {
    double getLat();
    double getLon();
    double getZ();
    Geoidal getGeoidal();
    GeoidalUnits getZUnits();
    void setZUnits(GeoidalUnits units);
}

