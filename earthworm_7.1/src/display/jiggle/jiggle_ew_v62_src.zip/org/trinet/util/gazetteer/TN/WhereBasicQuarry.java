package org.trinet.util.gazetteer.TN;
import org.trinet.util.gazetteer.*;
import java.sql.*;
import java.util.*;
/** Polymorphic type extension of WhereBasicPt */
public class WhereBasicQuarry extends WhereBasicPt {
    public WhereBasicQuarry() {
	super();
    }
    public WhereBasicQuarry(Connection conn) {
	super(conn);
    }
    public WhereBasicQuarry(Connection conn, Geoidal reference) {
	super(conn, reference);
    }
    public WhereBasicQuarry(Geoidal reference) {
	super(reference);
    }
    public WhereBasicQuarry(double lat, double lon, double z) {
	super(lat, lon, z);
    }

/** Returns Vector of WhereItems constructed using gazetteer database data for quarry type. */
    protected Vector getDatabaseData() {
	String sql = "SELECT * FROM GAZETTEERPT, GAZETTEERQUARRY WHERE GAZETTEERPT.TYPE = " +
		 GazetteerType.QUARRY.getCode() + 
		" AND GAZETTEERPT.GAZID = GAZETTEERQUARRY.GAZID (+)";
	return super.getDatabaseData(sql);
    }
}
