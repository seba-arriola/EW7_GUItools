package org.trinet.util.graphics;

import javax.swing.*;

public class InputVerifier {

    public InputVerifier() {}

    public boolean verify(JComponent input) {
        return true;
    }

    public boolean shouldYieldFocus(JComponent input) {
        return verify(input);
    }
}
