package org.trinet.jasi.TN;

import org.trinet.jasi.*;

//import java.sql.Connection;

import java.util.*;
import org.trinet.util.TimeSpan;

//import org.trinet.eventpriority.EventPriority;

/**
 * EventPriorityModelTN.java
 *
 *
 * Created: Wed Sep 20 10:14:41 2000
 *
 * @author Doug Given
 * @version
 */

public class EventPriorityModelTN
    //    extends org.trinet.eventpriority.EventPriority{
    extends EventPriority {

    public EventPriorityModelTN() {


    }

    // public static double getPriority (Connection conn, Solution sol) {
    public static double getPriority (Solution sol) {

//	setConnection(conn);

  return getPriority(sol.magnitude.value.doubleValue(),
         sol.datetime.doubleValue(),
         sol.quality.doubleValue() );
    }
    public static void main (String args[])
    {
        System.out.println ("Starting");

        System.out.println ("Making connection...");
  DataSource jc = new TestDataSource();

  // get by time
  double hoursBack = 24;
  final int secondsPerHour = 60*60;

        Calendar cal = Calendar.getInstance();
  java.util.Date date = cal.getTime();	// current epoch millisec
  long now = date.getTime()/1000;	// current epoch sec (millisecs -> seconds)

  long then = now - (long) (secondsPerHour * hoursBack);	// convert to seconds

  double dstart = (double) then;
  double dend   = (double) now;
  TimeSpan ts = new TimeSpan( dstart, dend);

  System.out.println ("Get entries by timespan: \n"+ ts.toString());

  //	Solution sol[] = Solution.getByTime(dstart, dend);
  Solution sol[] = Solution.create().getValidByTime(dstart, dend);
  System.out.println ("Found "+sol.length+" events.");

  //	QualityControlModel qc = QualityControlModel.getInstance();
  QualityControlModel qc = QualityControlModel.create();

  for (int i = 0; i < sol.length; i++)
  {
      System.out.println (sol[i].toSummaryString()+" Priority = "+ EventPriorityModelTN.getPriority(sol[i]));
  }

    }


} // EventPriorityModelTN

