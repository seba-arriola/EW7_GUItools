package org.trinet.jasi;
public interface MagnitudeGeneratorIF extends org.trinet.pcs.JasiSolutionChannelProcessorPhaseFilterIF {

    void setVerbose(boolean value) ;

    int calcChannelMagByTime(double start, double end) ;
    int calcChannelMag(SolutionList solList) ;
    int calcChannelMag(Solution [] solutions) ;
    int calcChannelMag(Solution sol)  ;
    int calcChannelMag(Solution sol, java.util.Collection waveformList)  ;
    int calcChannelMagForEvid(long evid) ;

    boolean calcSummaryMagForEvid(long id, boolean useExisting) ;
    boolean calcSummaryMag(Solution sol, boolean useExisting) ;
    int calcSummaryMagByTime(double start, double end, boolean useExisting) ;
    int calcSummaryMag(SolutionList solList, boolean useExisting) ;
    int calcSummaryMag(Solution [] solutions, boolean useExisting) ;
    Magnitude createSummaryMag(int count, double value, double err, double minRange, double maxGap) ;
    Magnitude getSummaryMagnitude() ;
    double getSummaryMagnitudeValue() ;

    void initCalibrList(java.util.Date date) ;
    boolean commitMag() throws JasiCommitException ;
}
