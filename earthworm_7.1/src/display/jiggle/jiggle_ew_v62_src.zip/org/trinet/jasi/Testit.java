package org.trinet.jasi;

public class Testit {

     public Testit() {
     }

     public static void main(String[] args) {
        System.out.println ("Making connection...");
	DataSource init = new TestDataSource();
     init.setWriteBackEnabled(true);

            Solution sol = Solution.create();

            sol.setId(1234567);

            try {
            sol.finalCommit();

            sol.setId(1234569);
            sol.delete();
            sol.commit();

            } catch (JasiCommitException ex) {
              System.out.println (ex.toString());
            }
     }

}