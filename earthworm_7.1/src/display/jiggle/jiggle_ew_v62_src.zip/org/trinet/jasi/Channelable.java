package org.trinet.jasi;

import org.trinet.util.gazetteer.LatLonZ;

/** Defines methods for classes that have a Channel. */
public interface Channelable {

// Can't call these g/setChannel() because that exists and returns String
// in Channel.class
    abstract  public void    setChannelObj(Channel chan);
    abstract  public Channel getChannelObj();

    abstract  public double calcDistance (LatLonZ loc);

    abstract  public void   setDistance(double distance);
    abstract  public double getDistance();

    abstract  public void   setHorizontalDistance(double distance);
    abstract  public double getHorizontalDistance();

    abstract  public void   setAzimuth(double azimuth);
    abstract  public double getAzimuth();
}
