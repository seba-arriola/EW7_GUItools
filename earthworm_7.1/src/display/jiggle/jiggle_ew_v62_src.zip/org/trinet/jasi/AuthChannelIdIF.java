package org.trinet.jasi;
/** Methods to retrieve NCDC database schema station channel description elements. */
public interface AuthChannelIdIF extends ChannelIdIF{

    String getAuth();
    String getSubsource();

    void setAuth(String auth);
    void setSubsource(String subsource);
}

