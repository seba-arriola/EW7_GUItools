package org.trinet.jasi;

import java.text.*;
import java.util.*;

public class TestMagWrite {

    public static void main (String args[])
    {
        System.out.println ("Starting");
        System.out.println ("Making connection...");
	DataSource init = new TestDataSource();  // make connection

	init.setWriteBackEnabled(true);
	// get one by evid


	//	int evid =  9526860;
	int evid =  9616101;

	System.out.println ("Get one entry by evid = "+ evid);

     // This reads in the amps, wf's, etc.
     org.trinet.jiggle.MasterView mv = new org.trinet.jiggle.MasterView();
//     mv.wfvList.setCachingEnabled(false);
     mv.setWaveFormLoadMode(mv.LoadNone);

     mv.defineByDataSource(evid);

	Solution sol1    = mv.solList.getSelected();

	System.out.println (sol1.toSummaryString()+" source="+sol1.source.toString());

     if (true) {
	// Test setting new Mag
	  System.out.println ("========== Set new Mag ");

       Magnitude newMag = Magnitude.create();

       newMag.value.setValue(1.11);
       newMag.subScript.setValue("n");
	  newMag.authority.setValue("CI");

       System.out.println ("Mag = "+newMag.toNeatString());

	  sol1.setPreferredMagnitude(newMag);;

	  System.out.println (sol1.toSummaryString());
	try {
          sol1.commit();
        } catch (Exception ex)  {
		System.err.println(ex);
		ex.printStackTrace();
        }
       // Test changing old Mag
       System.out.println ("========== Change Mag ");

       sol1.magnitude.value.setValue(2.22);
       System.out.println ("Mag = "+newMag.toNeatString());

	  System.out.println (sol1.toSummaryString());
          try {
	    sol1.commit();
          } catch (Exception ex)  {
		System.err.println(ex);
		ex.printStackTrace();
          }
     }
    }  // end of Main
}