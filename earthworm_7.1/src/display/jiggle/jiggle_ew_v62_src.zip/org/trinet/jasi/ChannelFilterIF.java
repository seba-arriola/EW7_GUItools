package org.trinet.jasi;
public interface ChannelFilterIF extends ChannelListIF { // implement this
    boolean summaryChannelType(String type) ;
    boolean filterChannelType(String type) ;
    boolean acceptChannelType(String type) ;
}

