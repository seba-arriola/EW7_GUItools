package org.trinet.jasi;
import java.util.*;
// DK import org.trinet.jdbc.table.*;
import org.trinet.util.*;

public interface ChannelDataIF {
    public ChannelIdIF getChannelId();
    public DateRange getDateRange();
    public boolean hasDateRange();
    public boolean store();
    public boolean load();
    public boolean load(ChannelIdIF stnchl);

    public ChannelDataIF load(ChannelDataIF chan) ;
    public ChannelDataIF load(ChannelDataIF chan, java.util.Date date) ;
    public Collection loadAll();
    public Collection loadAllCurrent() ;
    public Collection loadAll(java.util.Date date) ;

    public boolean equalsChannel(ChannelDataIF data);
    public boolean equalsChannelDateRange(ChannelDataIF data);

    public boolean copy(ChannelDataIF data); // replace same data member type values?
}

