package org.trinet.jasi.TN;

import org.trinet.jasi.*;

import org.trinet.jdbc.table.*;
import org.trinet.jdbc.table.SeqIds;
import org.trinet.jdbc.datatypes.*;
//import org.trinet.jdbc.table.Comment;

public class CommentTN extends Comment {
/*

*/

  long commid;

  private final static int TN_MAX_LENGTH = 80;

//  protected Comment commentRow;

  public CommentTN() {
  }


     /** Return the maximum allowed comment length.
     * Over ride in concrete class if another value is desired. */
     public int getMaxLength() {
       return TN_MAX_LENGTH;
     }


    /** Commit comment to dbase. Should be done BEFORE last update of Event table
    * keys so its key can be included. */
    public boolean commit() {

      if (!text.isUpdate() || text.isNull()) return false;

      commid = SeqIds.getNextSeq("commseq");

      Remark remarkRow = new Remark(commid, 1, text.toString());

      if ( remarkRow.insertRow(DataSource.getConnection()) < 1) return false;

      return true;
    }

    protected long getCommid() {
      return commid;
    }
}