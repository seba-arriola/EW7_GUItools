package org.trinet.jasi.coda;
public class CodaCalibrParms {
    public long clippingAmp;
    public long codaCutoffAmp;

    public String toString() {
        StringBuffer sb = new StringBuffer(48);
        sb.append(clippingAmp).append(" ").append(codaCutoffAmp);
        return sb.toString();
    }

    public boolean hasMagCorr() {
        return false;
    }
}

