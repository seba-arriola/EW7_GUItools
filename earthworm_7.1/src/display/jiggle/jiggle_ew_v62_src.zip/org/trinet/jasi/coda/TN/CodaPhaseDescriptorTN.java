package org.trinet.jasi.coda.TN;

import org.trinet.jasi.coda.*;

public class CodaPhaseDescriptorTN extends CodaPhaseDescriptor {
    public CodaPhaseDescriptorTN() {
        super(CodaType.P, CodaType.S, null);
    }
    public CodaPhaseDescriptorTN(String description) {
        super(CodaType.P, CodaType.S, description);
    }
    public CodaPhaseDescriptorTN(CodaType durationType, String description) {
        super(CodaType.P, durationType, description);
    }
}

