package org.trinet.jasi;
public interface CommitableIF {
    boolean commit() throws JasiCommitException ;
    void setAutoCommit(boolean value) ;
    boolean isAutoCommit() ;
}

