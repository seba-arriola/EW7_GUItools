package org.trinet.jasi.EW;

import org.trinet.jasi.*;
import java.sql.Connection;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class AmplitudeEW extends Amplitude
{

  public AmplitudeEW()
  {
  }
  public AmpList getByTime(Connection conn, double start, double stop)
  {
    /**@todo: implement this org.trinet.jasi.Amplitude abstract method*/
    return(new AmpList());
  }
  public AmpList getByMagnitude(long parm1, String[] parm2)
  {
    /**@todo: implement this org.trinet.jasi.Amplitude abstract method*/
    return(new AmpList());
  }
  public AmpList getBySolution(Solution sol)
  {
    /**@todo: implement this org.trinet.jasi.Amplitude abstract method*/
    return(new AmpList());
  }
  public AmpList getByMagnitude(Magnitude mag)
  {
    /**@todo: implement this org.trinet.jasi.Amplitude abstract method*/
    return(new AmpList());
  }
  public boolean commit()
  {
    /**@todo: implement this org.trinet.jasi.JasiReading abstract method*/
    return(false);
  }
  public AmpList getByTime(double start, double stop)
  {
    /**@todo: implement this org.trinet.jasi.Amplitude abstract method*/
    return(new AmpList());
  }
  public Amplitude getById(long id)
  {
    /**@todo: implement this org.trinet.jasi.Amplitude abstract method*/
    return(null);
  }
  public AmpList getByMagnitude(long magid)
  {
    /**@todo: implement this org.trinet.jasi.Amplitude abstract method*/
    return(new AmpList());
  }
  public AmpList getByMagnitude(Magnitude parm1, String[] parm2)
  {
    return(new AmpList());
    /**@todo: implement this org.trinet.jasi.Amplitude abstract method*/
  }
  public AmpList getBySolution(long parm1, String[] parm2)
  {
    /**@todo: implement this org.trinet.jasi.Amplitude abstract method*/
    return(new AmpList());
  }
  public AmpList getBySolution(long id)
  {
    /**@todo: implement this org.trinet.jasi.Amplitude abstract method*/
    return(new AmpList());
  }
}