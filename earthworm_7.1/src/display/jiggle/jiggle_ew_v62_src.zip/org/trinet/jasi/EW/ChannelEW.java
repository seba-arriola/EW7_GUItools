package org.trinet.jasi.EW;

import java.sql.Date;
import org.trinet.jasi.*;
import java.sql.Connection;
import java.util.Vector;
import org.trinet.util.gazetteer.LatLonZ;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ChannelEW extends Channel {

  private long idChan;
  EWChannel ewChannel;

  public ChannelEW() {
    idChan = 0;
  }
  public ChannelList getByComponent(String[] parm1, Date parm2) {
    /**@todo: implement this org.trinet.jasi.Channel abstract method*/
    return(new ChannelList());
  }
  public ChannelList readList(Connection conn, Date date)
  {
    /**@todo: implement this org.trinet.jasi.Channel abstract method*/
    // DK Cleanup  do something with conn
    return(readList(date));
  }

  public int getCurrentCount() {
    /**@todo: implement this org.trinet.jasi.Channel abstract method*/
    return(0);
  }
  public int getCount(Date date) {
    return(0);
    /**@todo: implement this org.trinet.jasi.Channel abstract method*/
  }
  public ChannelList getByComponent(String[] parm1) {
    return(new ChannelList());
    /**@todo: implement this org.trinet.jasi.Channel abstract method*/
  }
  public Channel lookUpChannel(Channel parm1)
  {
    Channel chTemp;
    this.setChannelObj(parm1);

    EWChannel ewChannel = new EWChannel();

    ewChannel.idChan = this.idChan;
    ewChannel.tReqTime = (int)((new java.util.Date()).getTime()/1000/*msec to sec*/);
    ewChannel.Read();
    chTemp = EWChannel_2_ChannelEW(ewChannel);
    parm1.copy(chTemp);

    return(chTemp);
  }

  public ChannelList readList(Date date)
  {
    Vector vEWChannelList;
    ChannelEW channelEW;
    ChannelList clChannels;

    if(ewChannel == null)
      ewChannel = new EWChannel();

    ewChannel.tReqTime = (int)((date.getTime())/1000 /*msec to sec */);
    vEWChannelList = ewChannel.ReadList();

    clChannels = new ChannelList(vEWChannelList.size());

    for(int i=0; i<vEWChannelList.size(); i++)
    {
      channelEW = EWChannel_2_ChannelEW((EWChannel)(vEWChannelList.get(i)));
      if(channelEW != null)
        clChannels.addWithoutCheck((Object)channelEW);
    }
    return(clChannels);
  } // end readList(Date)


  protected static ChannelEW EWChannel_2_ChannelEW(EWChannel ewChannel)
  {
    ChannelEW channelEW = new ChannelEW();

    channelEW.setChannelName(ewChannel.sNet, ewChannel.sSta, ewChannel.sComp, ewChannel.sComp);
    channelEW.set_idChan(ewChannel.idChan);
    channelEW.setLocation(ewChannel.sLoc);
    channelEW.latlonz = new LatLonZ(ewChannel.dLat, ewChannel.dLon, ewChannel.dElev);

    return(channelEW);
  }

  public static Channel lookUp(long idChan)
  {
    ChannelEW chan = new ChannelEW();
    chan.set_idChan(idChan);
    return(((Channel)chan).lookUpChannel(((Channel)chan)));
  }

    public boolean equals(Object x)
    {
      if (this == x)
        return(true);
      else if ( x == null)
        return(false);

      if(!(x instanceof ChannelEW))
        return super.equals(x);

      return(this.idChan == ((ChannelEW)x).idChan);
    }

    public Object clone() {
        ChannelEW chan = (ChannelEW)(super.clone());

        chan.set_idChan(this.idChan);
        return chan;
    }

    public long set_idChan(long IN_idChan)
    {
      this.idChan = IN_idChan;
      return(this.idChan);
    }

    public long get_idChan()
    {
      return(this.idChan);
    }

    public boolean sameAs(Object x)
    {
  if (x == null)
          return(false);

        if(this.equals(x))
          return(true);
        else
          return(((Channel)x).getChannelName().sameAs(channelId));
    }


  public ChannelList readList()
  {
    /**@todo: implement this org.trinet.jasi.Channel abstract method*/
    return(readList(new Date((new java.util.Date()).getTime())));
  }

    public Channel copy(Channel chan)
    {
      super.copy(chan);
      this.set_idChan(((ChannelEW)chan).idChan);
      this.ewChannel = ((ChannelEW)chan).ewChannel;

      return(this);
    }

}