package org.trinet.jasi;
public interface ChannelListIF { // implement this or extension of
    boolean initChannelList() ;
    boolean hasChannelList() ;
    void setChannelList(ChannelList list) ;
    Channel getChannelFromList(Channel channel) ;
    ChannelList loadChannelList(String filename);
    ChannelList loadChannelListFromDb(java.util.Date date);
    boolean storeChannelList(String filename) ;
}

