package org.trinet.jasi;

/**
 * Exception class that gets thrown when a mag method is passed an inapproriate
 * Amplitude object for the type of magnitude it calculates. For example: if you
 * pass an acceleration amp to an ML calculation class.
 *
 * Created: Tue Jun  6 11:07:09 2000
 *
 * @author Doug Given
 * @version */

public class WrongAmpTypeException extends Exception {
    
    public WrongAmpTypeException (String msg) {
	super (msg);
    }    
} // WrongAmpTypeException
