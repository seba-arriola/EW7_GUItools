package org.trinet.jasi;

import java.util.*;
import org.trinet.util.*;
import org.trinet.jdbc.table.*;

public class ChannelMagCorrectionList extends HashMap {
/**
* Only hashing by type works. You can't use the TimeSpan because a lookup is done
* for a particular POINT in time that is contained by the timespan of the corr.
*/
    protected HashMap hashMap;

//    protected ChannelDataIF lookUpInDataSource(ChannelDataIF cid, Date date) {
//            ChannelDataIF chanData = cid.load(cid, date);
//            if (chanData == null) return null;
//            add(chanData);
//            return chanData;
//    }

/*  * Only hashing by type works. You can't use the TimeSpan because a lookup is done
    * for a particular POINT in time that is contained by the timespan of the corr.
*/
    public void add(ChannelMagCorrection magCorr) {

//      put(magCorr.getType().hashCode(), magCorr);

    }
/* -------------------------------------------


    public ChannelMagCorrection lookUp(String type, EpochTime time) {
        ChannelMagCorrection probe = new ChannelMagCorrection(type, 0.0,
        ChannelDataIF chanData = lookUpInList(cid, date);
        return (chanData != null) ?  chanData : lookUpInDataSource(cid, date) ;
    }
// !!!!!!!!!!!!!!!!!!!!!!!!!!!! unfinished !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


    protected ChannelDataIF lookUpInList(ChannelDataIF cid, Date date) {

        if (chanDateMap == null) return null;

        Set aSet = (Set) chanDateMap.get(cid);
        if(aSet == null) return null;

        ChannelDataIF retVal = null;
        Iterator iter = aSet.iterator();
        while (iter.hasNext()) {
            DateRange dateRange = ((DateRange) iter.next());
            if (dateRange.contains(date)) {
                Integer key = makeHashKey(cid.getChannelId(), dateRange);  // combines dateRange with name into unique key object
                retVal =  (ChannelDataIF) chanParmMap.get(key);
                break;
            }
        }
        return retVal; // return cid; //??
    }

    private Integer makeHashKey(ChannelIdIF id, DateRange dateRange) {
        return new Integer( id.hashCode()+dateRange.hashCode() );
    }

    public boolean equals(Object object) {
        if (object == this) return true;
        if (object == null || object.getClass() != this.getClass()) return false;
        ChannelDataList list = (ChannelDataList) object;
        return ( chanDateMap.equals(list.chanDateMap) && chanParmMap.equals(list.chanParmMap) );
    }

    public Object clone() {
        ChannelDataList cdl = null;
        try {
            cdl = (ChannelDataList) super.clone();
            cdl.chanDateMap = (HashMap) this.chanDateMap.clone();
            cdl.chanParmMap = (HashMap) this.chanParmMap.clone();
        }
        catch(CloneNotSupportedException ex) {
             ex.printStackTrace();
        }
        return cdl;
    }

   public int hashCode() {
        return chanDateMap.hashCode() + chanParmMap.hashCode() ;
   }
-------------------------------------- */


}   // end of ChannelDataList class

