package org.trinet.jasi;
/** Methods to retrieve NCDC database schema station channel description elements. */
public interface ChannelIdIF {
    String getSta();
    String getNet();
    String getSeedchan();
    String getLocation();
    String getChannel();
    String getChannelsrc();

    void setSta(String sta);
    void setNet(String net);
    void setSeedchan(String seedchan);
    void setLocation(String location);
    void setChannel(String channel);
    void setChannelsrc(String channelsrc);
    Object clone();
    String toDelimitedString(char delimiter);
}

