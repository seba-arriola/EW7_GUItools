package org.trinet.jasi.TN;

import org.trinet.jasi.*;



/** Concrete class that defines how event types are mapped in the TriNet schema. */
public class EventTypeMapTN extends EventTypeMap {

    /** Define TriNet schema event type strings. */
    static String thisType[] = {"le", "qb", "re", "ts",
           "sn", "nt", "st", "uk"};

    static String thisLocalDefault = "uk";

     public EventTypeMapTN() {

      localType = thisType;
      localDefault = thisLocalDefault;

     }
}