package org.trinet.jasi.TN;

import org.trinet.jasi.*;
import java.sql.Connection;

public interface TNCommitableIF extends CommitableIF { // implement this or extension of
    Connection getConnection() ;
    void setConnection(Connection connection) ;
}

