package org.trinet.pcs;
public interface JasiProcessingControllerIF extends ProcessingControllerIF {
    static final String PCS_POST_EVENT_IDS_FOR_DATERANGE_PROCESSING =
       "SELECT EVENT.EVID FROM EVENT,ORIGIN WHERE EVENT.PREFOR=ORIGIN.ORID AND ORIGIN.DATETIME BETWEEN ? AND ?";

    static final String PCS_CHECK_EVENT_ID_SQL_QUERY = "SELECT EVID FROM EVENT WHERE EVID = ?";

    int resultSolution(org.trinet.jasi.Solution solution, int resultCode) ;
    int processSolution(org.trinet.jasi.Solution solution) ;
    void setProcessingModule(JasiSolutionProcessorIF module);
    void setProcessingModuleMode(SolutionProcessingMode processingMode);
}
