package org.trinet.pcs;
public class SolutionProcessingMode {
    private String description;
    private int id;    
    protected SolutionProcessingMode(String description, int id) {
       this.description = description;
       this.id = id;
    }
    public int getIdCode() {
        return id;
    }
    public String getDescription() {
        return description;
    }
    public String toString() {
        return description + "=" + id;
    }
}
