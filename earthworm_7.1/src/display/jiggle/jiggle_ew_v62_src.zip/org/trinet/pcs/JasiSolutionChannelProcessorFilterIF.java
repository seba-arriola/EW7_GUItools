package org.trinet.pcs;
public interface JasiSolutionChannelProcessorFilterIF extends JasiSolutionChannelProcessorIF {
    boolean summaryChannelType(String type) ;
    boolean filterChannelType(String type) ;
    boolean acceptChannelType(String type) ;
}

