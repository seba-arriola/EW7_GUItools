package org.trinet.pcs;
import org.trinet.jasi.*;
public interface JasiSolutionProcessorIF {
    int processSolution(long evid) ;
    int processSolution(Solution sol)  ;
    int processSolution(Solution [] solutions) ;
    int processSolution(SolutionList solList) ;
    void setSolutionProcessingMode(SolutionProcessingMode processingMode) ;
    SolutionProcessingMode getSolutionProcessingMode() ;
    boolean isValidId(long id) ;
    boolean isValidSolution(Solution solution) ;
    void setSolution(Solution sol) ;
    Solution getSolution() ;
}
