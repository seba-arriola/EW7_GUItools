package org.trinet.pcs;
public class CodaSolutionProcessingResult extends ProcessingResult {
    private CodaSolutionProcessingResult(String description, int idCode) {
        super(description, idCode);
    }
}
