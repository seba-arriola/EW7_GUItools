package org.trinet.pcs;
import org.trinet.jasi.*;
public interface JasiSolutionChannelProcessorPhaseFilterIF extends JasiSolutionChannelProcessorFilterIF {
    double getPhaseTravelTime(Channel chan, String type) ;
}
