package org.trinet.pcs;
  /**
   * Set the 'result' field of a data object in the given state.
   */
public class PutResult
{
      //TODO: get defaults from a file?
      String group;	// = "ROUTINE";
      String table;	// = "EVENT";
      long    id ;
      String state;
      int    result;

  public static void main (String args[])
    {
        PutResult p = new PutResult ();

        if (args.length < 5)
        {
	  System.out.println("SYNTAX: PutResult <group> <table> <id> <state> <result>");
	  return ;
	} else {
	  
	  p.group = args[0];
	  p.table = args[1];
	  p.id = Long.parseLong(args[2]);
	  p.state = args[3];
	  p.result = Integer.valueOf(args[4]).intValue(); // string -> int

	}

      int nchanged = ProcessControl.putResult (p.group, p.table, p.id, p.state, p.result);

      // Provide some user feedback
      if (nchanged == 0)
	{
	  System.out.println (p.id+" : no such group/table/state");
	} else {
	  System.out.println (p.id+" : " + p.state +" result =>   "+p.result);
	}
      // TODO: look up transition and inform user??
    }

}
