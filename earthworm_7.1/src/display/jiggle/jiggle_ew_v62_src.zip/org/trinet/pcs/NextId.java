package org.trinet.pcs;

  /**
   * Get the next ID for the given group/table/state.
   */
class NextId
{

  public static void main (String args[])
    {
      StateRow sr = new StateRow();

        if (args.length != 3)
        {
	  System.out.println("SYNTAX: next <group> <table> <state>");
	  return ;
	} else {
	  
	  sr.controlGroup = args[0];
	  sr.sourceTable  = args[1];
	  sr.state        = args[2];

	}

	//        StateRow next[] = 
	//	  StateRow.getNextArray(sr.controlGroup, sr.sourceTable, sr.state);

        StateRow next = 
	  StateRow.getNext(sr.controlGroup, sr.sourceTable, sr.state);

	if (next != null) System.out.println (next.id);
	//	StateRow.dump(next);

    }
}
