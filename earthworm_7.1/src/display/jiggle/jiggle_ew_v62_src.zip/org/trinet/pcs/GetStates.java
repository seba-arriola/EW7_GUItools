package org.trinet.pcs;

  /**
   * Put an data object in the given state/rank.
   */
class GetStates
{

  public static void main (String args[])
    {
        StateRow p = new StateRow();

	//NOTE: 
	// this pr1, pr2, pr3 nonsense was made necessary by compiler errors
	// "Variable pr may not have been initialized"

	switch (args.length) {

	case 3:
	  p.controlGroup = args[0];
	  p.sourceTable  = args[1];
          try {
	      p.id = Long.parseLong(args[2]);
	      StateRow pr3[] = StateRow.get (p.controlGroup, p.sourceTable, p.id);
	      dumpResults(pr3);
          }
          catch (NumberFormatException ex) {
              p.state = args[2];
	      StateRow pr3[] = StateRow.get (p.controlGroup, p.sourceTable, p.state);
	      dumpResults(pr3);
          }

	  break;

	case 2:
	  p.controlGroup = args[0];
	  p.sourceTable  = args[1];
	  StateRow pr2[] = 
	    StateRow.get (p.controlGroup, p.sourceTable);    
	  dumpResults(pr2);
	  break;

	case 1:
	  p.controlGroup = args[0];
	  StateRow pr1[] = StateRow.get (p.controlGroup);    
	  dumpResults(pr1);
	  break;

	case 0:
	  StateRow pr0[] = StateRow.get ();    
	  dumpResults(pr0);
	  break;

	default:
	  System.out.println("SYNTAX: getstates <group> [<table>] [<id> || <state>]");
	  return ;
	}

    }

  public static void dumpResults (StateRow pr[])
    {
      if (pr == null) 
	{ 
	// System.out.println (" * No entries *");
	  return;
	}
      for (int i=0; i < pr.length; i++)
	{
	  System.out.println (pr[i].toOutputString());
	}      
    }
}
