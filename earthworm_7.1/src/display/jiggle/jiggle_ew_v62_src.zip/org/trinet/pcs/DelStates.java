package org.trinet.pcs;
  /**
   * Put an data object in the given state/rank.
   *  % SYNTAX: DelStates <group> <table> <id>
   */
class DelStates
{

  public static void main (String args[])
    {
        StateRow p = new StateRow();
	int ndel = 0;

	//NOTE: 
	// this pr1, pr2, pr3 nonsense was made necessary by compiler errors
	// "Variable pr may not have been initialized"

	switch (args.length) {

	case 3:
	  p.controlGroup = args[0];
	  p.sourceTable  = args[1];
	  p.id = Long.parseLong(args[2]);
	  ndel = StateRow.delete (p.controlGroup, p.sourceTable, p.id);

	  break;

	case 2:
	  p.controlGroup = args[0];
	  p.sourceTable  = args[1];
	  ndel = StateRow.delete (p.controlGroup, p.sourceTable);    

	  break;

	case 1:
	  p.controlGroup = args[0];
	  ndel = StateRow.delete (p.controlGroup);    

	  break;

	  /* Too dangerous
	case 0:
	  ndel = StateRow.delete ();    

 	  break;
	  */

	default:
	  System.out.println("SYNTAX: delstates <group> [<table>] [<id>]");
	  
	}
	System.out.println (ndel + " table rows deleted.");
	  return ;

    }

}
