package org.trinet.pcs;

  /**
   * Put an data object in the given state/rank.
   *  % SYNTAX: GetState <group> <table> <id>
   */
class GetState
{

  public static void main (String args[])
    {
        ProcessRow p = new ProcessRow();
	//	ProcessRow pr[];
	//NOTE: 
	// this pr1, pr2, pr3 nonsense was made necessary by compiler errors
	// "Variable pr may not have been initialized"

	switch (args.length) {

	case 3:
	  p.controlGroup = args[0];
	  p.sourceTable  = args[1];
	  p.id = Integer.valueOf(args[2]).intValue();
	  ProcessRow pr3[] = 
	    ProcessRow.get (p.controlGroup, p.sourceTable, p.id);
	  dumpResults(pr3);
	  break;

	case 2:
	  p.controlGroup = args[0];
	  p.sourceTable  = args[1];
	  ProcessRow pr2[] = 
	    ProcessRow.get (p.controlGroup, p.sourceTable);    
	  dumpResults(pr2);
	  break;

	case 1:
	  p.controlGroup = args[0];
	  ProcessRow pr1[] = ProcessRow.get (p.controlGroup);    
	  dumpResults(pr1);
	  break;

	case 0:
	  ProcessRow pr0[] = ProcessRow.get ();    
	  dumpResults(pr0);
	  break;

	default:
	  System.out.println("SYNTAX:  GetState <group> [<table>] [<id>]");
	  return ;
	}

    }

  public static void dumpResults (ProcessRow pr[])
    {
      if (pr == null) 
	{ 
	  System.out.println (" * No entries *");
	  return;
	}
      for (int i=0; i < pr.length; i++)
	{
	  System.out.println (pr[i].toOutputString());
	}      
    }
}
