package org.trinet.pcs;

  /**
   * Put an data object in the given state/rank.
   *  % SYNTAX: GetState <group> <table> <id>
   */
class GetTransitions
{

  public static void main (String args[])
    {
        TransitionRow t = new TransitionRow();

	//NOTE: 
	// this tr1, tr2, tr3 nonsense was made necessary by compiler errors
	// "Variable tr may not have been initialized"

	switch (args.length) {

	case 3:
	  t.controlGroup = args[0];
	  t.sourceTable  = args[1];
	  t.stateOld      = args[2];
	  TransitionRow tr3[] = 
	    TransitionRow.get (t.controlGroup, t.sourceTable, t.stateOld);
	  TransitionRow.dump(tr3);
	  break;

	case 2:
	  t.controlGroup = args[0];
	  t.sourceTable  = args[1];
	  TransitionRow tr2[] = 
	    TransitionRow.get (t.controlGroup, t.sourceTable);    
	  TransitionRow.dump(tr2);
	  break;

	case 1:
	  t.controlGroup = args[0];
	  TransitionRow tr1[] = TransitionRow.get (t.controlGroup);    
	  TransitionRow.dump(tr1);
	  break;

	case 0:
	  TransitionRow tr0[] = TransitionRow.get ();    
	  TransitionRow.dump(tr0);
	  break;

	default:
	  System.out.println("SYNTAX:  GetTransitions [<group>] [<table>] [<state>] ");
	  return ;
	}

    }


}
