package org.trinet.jdbc.datatypes;
public interface DataNumeric {
    // Empty
}
