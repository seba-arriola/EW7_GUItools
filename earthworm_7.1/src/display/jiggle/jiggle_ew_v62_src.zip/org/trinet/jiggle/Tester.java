package org.trinet.jiggle;
import java.lang.reflect.*;
import java.net.URL;

/**
 * Title:        Your Product Name
 * Description:  Your description
 * Copyright:    Copyright (c) 2001
 * Company:      USGS
 * @author Doug Given
 * @version
 */

public class Tester {

  public Tester() {
  }
  public static void main(String[] args) {
    //Tester tester1 = new Tester();

    int knt = 0;
    Runtime runtime = Runtime.getRuntime();
    long free ;
    long total ;
    double used ;
    String str;

    WFViewList list = new WFViewList();
    WFPanelList plist = new WFPanelList();

    try {
      if (true) {

	free  = runtime.freeMemory();
	total = runtime.totalMemory();
	used = ((double)(total - free) / (double)total ) * 100.0;
	str = " Memory usage: " +
	    " total = " + total + " bytes" +
	    " free  = " + free + " bytes" +
	    " %used = " + used + "%  ";

	plist.add(new WFPanel(new WFView()));

	  System.out.println (knt++ + " " + str);

          System.out.println( "version = "+System.getProperty("java.version"));
          System.getProperties().list(System.out);

      }


    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }




}