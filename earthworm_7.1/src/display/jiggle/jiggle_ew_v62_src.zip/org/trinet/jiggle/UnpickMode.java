package org.trinet.jiggle;

/**
 * Used to provide globally accessible view of the Unpick mode.
 */

public class UnpickMode  {

    static boolean mode = false;

    UnpickMode() {
	
    }
    /** Sets mode's current state, t or f */
    public static void set (boolean tf) {
	mode = tf;
    }

    /** Returns mode's current state, t or f */
    public static boolean get () {
	return mode;
    }

    /** More gramatical method. Same as get() */
    public static boolean isTrue() {
	return mode;
    }
} // UnpickMode
