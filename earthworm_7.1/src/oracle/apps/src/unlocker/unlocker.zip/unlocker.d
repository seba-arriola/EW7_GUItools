
# configuration file for archiver


#
# Database connection parameters
#
#
DBuser     ewdb_main
DBpassword PASSWORD
DBservice  eqsX.usgs


#
# Logfiledir - where log files are written
#
Logfiledir j:\temp

#
# This program is meant to be run out of cron to clean
# up old events. The configuration options below allows
# for this period cleanup by specifying the start date 
# with respect to the date of the cleanup, and the number
# of days to clean up.
#


#
# Debug - optional debug flag
#
#Debug		1


DaysTillReckoning     290.5
